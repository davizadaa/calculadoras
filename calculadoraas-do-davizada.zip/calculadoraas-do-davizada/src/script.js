function calcularArea() {
  var lado = document.getElementById("lado").value;
  if (lado > 0) {
    var area = 6 * Math.pow(lado, 2);
    document.getElementById("resultado").innerHTML =
      "A área total do cubo é: " + area.toFixed(2) + " unidades quadradas.";
  } else {
    document.getElementById("resultado").innerHTML =
      "Por favor, insira um valor válido para o lado.";
  }
}

function calcularAreaParalelepipedo() {
  var a = document.getElementById("dimensaoA").value;
  var b = document.getElementById("dimensaoB").value;
  var c = document.getElementById("dimensaoC").value;

  if (a > 0 && b > 0 && c > 0) {
    var area = 2 * (a * b + b * c + a * c);
    document.getElementById("resultado").innerHTML =
      "A área total do paralelepípedo é: " +
      area.toFixed(2) +
      " unidades quadradas.";
  } else {
    document.getElementById("resultado").innerHTML =
      "Por favor, insira valores válidos para todas as dimensões.";
  }
}

function calcularAreaCilindro() {
  var raio = document.getElementById("raio").value;
  var altura = document.getElementById("altura").value;

  if (raio > 0 && altura > 0) {
    var area = 2 * Math.PI * raio * (raio + altura);
    document.getElementById("resultado").innerHTML =
      "A área total do cilindro é: " + area.toFixed(2) + " unidades quadradas.";
  } else {
    document.getElementById("resultado").innerHTML =
      "Por favor, insira valores válidos para o raio e a altura.";
  }
}
